jQuery( document ).ready( function( $ )
{
